the code is written in Python 2.7, and the relevant packages are needed (numpy, scipy, datetime, matplotlib, sklearn) to be well installed before.
in order to run the code, the data files (*.csv) and the codes (*.py) needed to be put into the same folder
and then simply run the five code one by one.