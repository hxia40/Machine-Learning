This program is written under jython.

TSP, Filpflop, continuouspeaks: the three optimization

NN0: Neural Network estimated by gradient descent
NN1: Neural Network estimated by RHC
NN2: Neural Network estimated by SA
NN3: Neural Network estimated by GA


Running each of them will return text files that include the fittness, accuracy (for NN), and the number of function iteration spent during optimization.


Special Credits: source code largely base on materials from http://github.com/JonathanTay/

